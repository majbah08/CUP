CREATE FUNCTION log (numeric) RETURNS numeric
	LANGUAGE sql
AS $$
select pg_catalog.log(10, $1)
$$
